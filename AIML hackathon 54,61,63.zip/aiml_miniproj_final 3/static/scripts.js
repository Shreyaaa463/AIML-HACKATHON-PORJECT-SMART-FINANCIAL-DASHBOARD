// Tab switching functionality
function showTab(tabName) {
    // Hide all tabs
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    // Remove active class from all buttons
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    // Show selected tab
    document.getElementById(tabName + '-tab').classList.add('active');
    
    // Add active class to clicked button
    event.target.classList.add('active');
}

// Loan prediction form handler
document.addEventListener("DOMContentLoaded", function() {
    // Loan form submission
    document.getElementById('loan-form').onsubmit = function(e) {
        e.preventDefault();
        var form = e.target;
        var data = new FormData(form);

        fetch('/predict', {method: 'POST', body: data})
            .then(res => res.json())
            .then(obj => {
                if (obj.error) {
                    document.getElementById('loan-result').innerHTML = "⚠️ Error: " + obj.error;
                    return;
                }

                document.getElementById('loan-result').innerHTML =
                    '<h3>Prediction Result:</h3><span style="color:' + 
                    (obj.prediction === 1 ? '#16a34a' : '#dc2626') + '; font-size: 24px;">' +
                    (obj.prediction === 1 ? '✅ Loan Approved' : '❌ Loan Denied') + '</span>';

                if (obj.metrics) {
                    const m = obj.metrics;
                    document.getElementById('loan-metrics').innerHTML = `
                        <h3>Model Performance (${m.model})</h3>
                        <table>
                            <tr><th>Metric</th><th>Value</th></tr>
                            <tr><td>Accuracy</td><td>${m.accuracy}</td></tr>
                            <tr><td>Precision</td><td>${m.precision}</td></tr>
                            <tr><td>Recall</td><td>${m.recall}</td></tr>
                            <tr><td>F1-Score</td><td>${m.f1}</td></tr>
                        </table>`;
                }
            })
            .catch(err => {
                console.error("Prediction failed:", err);
                document.getElementById('loan-result').innerHTML =
                    "❌ Error: Could not connect to server.";
            });
    };

    // Credit card form submission
    document.getElementById('credit-form').onsubmit = function(e) {
        e.preventDefault();
        var form = e.target;
        var data = new FormData(form);

        fetch('/predict_credit', {method: 'POST', body: data})
            .then(res => res.json())
            .then(obj => {
                if (obj.error) {
                    document.getElementById('credit-result').innerHTML = "⚠️ Error: " + obj.error;
                    return;
                }

                document.getElementById('credit-result').innerHTML =
                    '<h3>Prediction Result:</h3><span style="color:' + 
                    (obj.prediction === 1 ? '#16a34a' : '#dc2626') + '; font-size: 24px;">' +
                    (obj.prediction === 1 ? '✅ Credit Card Approved' : '❌ Credit Card Denied') + '</span>';

                if (obj.metrics) {
                    const m = obj.metrics;
                    document.getElementById('credit-metrics').innerHTML = `
                        <h3>Model Performance (${m.model})</h3>
                        <table>
                            <tr><th>Metric</th><th>Value</th></tr>
                            <tr><td>Accuracy</td><td>${m.accuracy}</td></tr>
                            <tr><td>Precision</td><td>${m.precision}</td></tr>
                            <tr><td>Recall</td><td>${m.recall}</td></tr>
                            <tr><td>F1-Score</td><td>${m.f1}</td></tr>
                        </table>`;
                }
            })
            .catch(err => {
                console.error("Prediction failed:", err);
                document.getElementById('credit-result').innerHTML =
                    "❌ Error: Could not connect to server.";
            });
    };
});

// 🚨 FRAUD DETECTION FUNCTION
function predictFraud() {
    const data = {
        TransactionAmount: document.getElementById("f_amount").value,
        CustomerAge: document.getElementById("f_age").value,
        TransactionDuration: document.getElementById("f_duration").value,
        LoginAttempts: document.getElementById("f_attempts").value,
        AccountBalance: document.getElementById("f_balance").value
    };

    fetch("/predict_fraud", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(obj => {
        if (obj.error) {
            document.getElementById("fraud-result").innerHTML =
                "⚠️ Error: " + obj.error;
            return;
        }

        document.getElementById("fraud-result").innerHTML = `
            <h3>Fraud Detection Result</h3>
            <p style="font-size:20px; font-weight:bold; color:${obj.prediction === "FRAUD" ? '#dc2626' : '#16a34a'};">
                ${obj.prediction === "FRAUD" ? "❌ Fraud Detected!" : "✅ Transaction is Normal"}
            </p>
            <p><b>Anomaly Score:</b> ${obj.score}</p>
        `;
    })
    .catch(err => {
        console.error(err);
        document.getElementById("fraud-result").innerHTML =
            "❌ Error: Could not connect to server.";
    });
}

